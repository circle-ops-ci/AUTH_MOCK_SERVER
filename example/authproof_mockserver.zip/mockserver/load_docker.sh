docker stop cbauthmocksrv
docker rm cbauthmocksrv

docker load < cbauthmocksrv.tar

docker create \
-p 8892:8892 \
--name cbauthmocksrv \
-v ${PWD}/conf:/cbauthmocksrv/conf \
cbauthmocksrv:build

docker start cbauthmocksrv
